<?php

$keyId = 'rzp_test_uccNt4nYvSk6KJ';//TEST KEY
//$keyId = 'rzp_live_4fyMA0LJOLfTgC'; //LIVE KEY

$keySecret = 'FEXpK3fxcp0MSmaBrmwdVZva';//TEST 
//$keySecret =  'Mfb7o4wDr9avH2GSapccY0iP'; //LIVE

$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
